# Aplikasi sederhana manajemen surat dengan PHP MySQLi

Administrator:
User: admin, Pass: admin

Staf TU:
User:staf1, Pass:12345

Pejabat Disposisi:
User:kasubag_uk, Pass:admin

Pegawai:
User:andika, Pass:admin
